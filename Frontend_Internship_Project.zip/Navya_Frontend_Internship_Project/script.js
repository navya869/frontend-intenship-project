// Interactive behaviours for the front-end practice website.
const themeButton = document.querySelector("#themeButton");
themeButton.addEventListener("click", () => {
  document.body.classList.toggle("alt-mood");
  const changed = document.body.classList.contains("alt-mood");
  themeButton.textContent = changed ? "Return to original mood" : "Change page mood";
});

document.querySelectorAll(".filter-btn").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".filter-btn").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    const filter = button.dataset.filter;
    document.querySelectorAll(".idea-item").forEach((card) => {
      card.classList.toggle("d-none", filter !== "all" && card.dataset.category !== filter);
    });
  });
});

const loadPostsButton = document.querySelector("#loadPosts");
const postsList = document.querySelector("#postsList");
const apiStatus = document.querySelector("#apiStatus");

loadPostsButton.addEventListener("click", async () => {
  loadPostsButton.disabled = true;
  loadPostsButton.textContent = "Loading…";
  apiStatus.textContent = "Fetching sample posts from JSONPlaceholder…";
  postsList.innerHTML = "";
  try {
    const response = await fetch("https://jsonplaceholder.typicode.com/posts?_limit=6");
    if (!response.ok) throw new Error("The server returned an error.");
    const posts = await response.json();
    posts.forEach((post) => {
      const column = document.createElement("div");
      column.className = "col-md-6 col-lg-4";
      const article = document.createElement("article");
      article.className = "post-card";
      const number = document.createElement("span");
      number.className = "post-number";
      number.textContent = `SAMPLE POST ${String(post.id).padStart(2, "0")}`;
      const heading = document.createElement("h3");
      heading.textContent = post.title;
      const paragraph = document.createElement("p");
      paragraph.textContent = post.body;
      article.append(number, heading, paragraph);
      column.append(article);
      postsList.append(column);
    });
    apiStatus.textContent = "Six sample posts loaded successfully.";
  } catch (error) {
    apiStatus.textContent = "Posts could not load. Check your internet connection and try again.";
  } finally {
    loadPostsButton.disabled = false;
    loadPostsButton.textContent = "Load sample posts";
  }
});

const contactForm = document.querySelector("#contactForm");
const formResult = document.querySelector("#formResult");
contactForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const name = document.querySelector("#fullName");
  const email = document.querySelector("#email");
  const message = document.querySelector("#message");
  const fields = [name, email, message];
  let valid = true;
  fields.forEach((field) => {
    const fieldIsValid = field.checkValidity();
    field.classList.toggle("is-invalid", !fieldIsValid);
    field.classList.toggle("is-valid", fieldIsValid);
    if (!fieldIsValid) valid = false;
  });
  if (!valid) {
    formResult.textContent = "Please check the highlighted fields.";
    formResult.style.color = "#b42318";
    return;
  }
  formResult.textContent = `Thanks, ${name.value.trim()}! The demo form is valid. No information was sent.`;
  formResult.style.color = "#23734d";
  contactForm.reset();
  fields.forEach((field) => field.classList.remove("is-valid"));
});

document.querySelector("#year").textContent = new Date().getFullYear();
