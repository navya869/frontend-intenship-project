# Level 4 — Expert
## Task 7: Component-Based Styling
**Files:** `../index.html`, `../styles.css`  
Bootstrap is included through its CDN and used for the responsive navbar, grid, buttons, and form controls.

## Task 8: Introduction to CSS Preprocessing
**File:** `../styles.scss`  
Includes Sass variables, nested selectors, and a media query. Sass source is provided separately.

## Evidence to capture
- Show the responsive Bootstrap navigation and card layout.
- Keep `styles.scss` as the source file; if required, compile it with Sass and show the generated CSS.
