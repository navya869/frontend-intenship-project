# Level 2 — Intermediate
## Task 3: Responsive Design
**Files:** `../index.html`, `../styles.css`  
The page uses a responsive grid, flexible typography, and media queries for smaller screens.

## Task 4: Interactive Button
**Files:** `../index.html`, `../script.js`  
Click **Change page mood** to switch the page's colour theme.

## Evidence to capture
- Show the page at desktop width and mobile width.
- Capture the page before and after clicking the mood button.
