# Submission checklist

The PDF says to complete at least 6 of 8 tasks and keep a separate file for each level. This project includes examples for all 8 tasks.

- [ ] Test the main website in a browser.
- [ ] Test responsive behaviour by resizing the browser.
- [ ] Test the mood-switch button.
- [ ] Load the API posts while connected to the internet.
- [ ] Test both invalid and valid form submissions.
- [ ] Review the Level 1–4 notes and capture your own screenshots.
- [ ] Record a short video showing the working project.
- [ ] Post the video on LinkedIn and tag Cognifyz Technologies as requested in the PDF.
- [ ] Confirm the internship submission form and any later instructions when they are shared.
- [ ] Replace the contact identifier with your complete email address only if you want to publish it.

## Important
Review and personalize the code before submitting. You should be able to explain what each file does and demonstrate the features live.
