# Level 3 — Advanced
## Task 5: API Integration
**Files:** `../index.html`, `../script.js`  
The page calls JSONPlaceholder with `fetch()`, parses JSON, and creates post cards dynamically. Internet access is needed.

## Task 6: Form Styling and Validation
**Files:** `../index.html`, `../styles.css`, `../script.js`  
The contact form checks name, email format, and message length, then displays feedback. It does not transmit form data.

## Evidence to capture
- Click **Load sample posts** and capture the returned cards.
- Submit an empty form, then a valid form, and capture the feedback.
