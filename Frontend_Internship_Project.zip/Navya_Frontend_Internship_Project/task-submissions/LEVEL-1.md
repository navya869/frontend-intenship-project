# Level 1 — Beginner
## Task 1: Basic HTML Page
**File:** `../tasks/task-01-basic-html.html`  
Includes the HTML document structure, title, heading, paragraph, and image.

## Task 2: Styling with Inline CSS
**File:** `../tasks/task-02-inline-css.html`  
Uses inline styles for typography, text colour, background, spacing, and image presentation.

## Evidence to capture
- Open both pages in a browser.
- Take a screenshot of each page.
