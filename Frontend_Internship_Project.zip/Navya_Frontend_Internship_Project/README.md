# Navya — Front-End Development Lab

A responsive single-page practice project based on the tasks in the Cognifyz Technologies Front-End Development internship PDF.

## Features
- Basic HTML page structure, headings, paragraphs, and a decorative CSS illustration (Task 1)
- Inline styling demonstration in `tasks/task-02-inline-css.html` (Task 2)
- Responsive CSS and media queries (Task 3)
- JavaScript button that changes the page mood (Task 4)
- Fetches six sample posts from JSONPlaceholder and renders them on the page (Task 5)
- Client-side form validation with feedback (Task 6)
- Bootstrap navigation, grid, buttons, and responsive components (Task 7)
- Sass source with variables and nesting in `styles.scss` (Task 8)

## Run the project
1. Extract the ZIP file.
2. Open `index.html` in a browser. For best results, use VS Code with the Live Server extension.
3. Internet is required for Bootstrap CDN assets and the sample posts API.
4. To test the API, click **Load sample posts**.
5. To test the form, submit it empty and then try valid details. The form is only a demo and does not send data anywhere.

## Compile Sass (optional)
Install Sass if you have Node.js:
```bash
npm install -g sass
sass styles.scss styles.css
```
The main site uses the complete `styles.css` file directly. The Sass file is included as the source for Task 8; if you compile it, save the output separately first or compare it before replacing the main stylesheet.

## Before submission
- Open and test the page in your own browser.
- Make sure you can explain each task and the code you changed.
- Add your full email address if you want it displayed publicly. The supplied identifier `kuninavya09` is included as written because a full email address was not provided.
- The internship PDF asks for a separate file for each level and a video showcasing the completed tasks. See `task-submissions/` for a checklist.

## Project structure
- `index.html` — main website
- `styles.css` — responsive styles
- `script.js` — interactions, API, validation
- `styles.scss` — Sass source
- `tasks/` — separate demonstrations for tasks and levels
- `task-submissions/` — completion notes and submission checklist
